/*
 * ClamAV do-nothing config.h to appease other autoconf projects when ClamAV is built with HAVE_CONFIG_H
 */

#ifndef CONFIG_H
#define CONFIG_H 1

#endif // CONFIG_H
