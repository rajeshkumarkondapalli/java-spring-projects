import "./styles.css";
import React, {useState} from "react";
import axios from 'axios';

export default function App() {
  const [output, setOutput] = useState('...');

  const [formValue, setformValue] = React.useState({
    text: '',
  });

const handleSubmit = async(event) => {
  event.preventDefault();

  // alert(formValue.text)
  const URL = "http://localhost:5000/pingdo";

  const response =await axios.get(URL, {
    headers: {
      'Access-Control-Allow-Origin': true,
    },
    params: {
      query: formValue.text,
    },
  })
  // alert(response.data)
  setOutput(response.data)

}

  const handleChange = (event) => {
    setformValue({
      ...formValue,
      [event.target.name]: event.target.value
    });
  }

  return (
    <div  >
    
    <form onSubmit={handleSubmit}>
      <h1>Chatbot</h1>
      <input
        type="text"
        name="text"
        className="search"
        placeholder="enter an text"
        value={formValue.text}
        onChange={handleChange}
      />
      
      {/* <button
        type="submit"
      >
        Enter..
      </button> */}
    </form>
    
    <div className="output">
      <p>{output}</p>
    </div>

   </div>
  )
}
