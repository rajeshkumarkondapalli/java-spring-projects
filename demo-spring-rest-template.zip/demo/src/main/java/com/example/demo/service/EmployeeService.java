package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.demo.repository.Employee;

@Service
public class EmployeeService {
	
	List<Employee> employees;
	
	
	public EmployeeService() {
		super();
		Employee emp = new Employee("dude", 1, 100000L);
		this.employees = new ArrayList<Employee>();
		employees.add(emp);
	}	

	public EmployeeService(List<Employee> employees) {
		super();
		this.employees = employees;
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public Employee createEmployee(Employee employee) {
		employees.add(new Employee(employee));
		return employee;
	}

	public ResponseEntity<Employee> getEmployeeById(int id) {
		return ResponseEntity.ok().body(employees.get(id));
		
	}

}
