package com.example.demo.repository;

import org.springframework.stereotype.Component;

@Component
public class Employee {
	
	private String name;
	private int id;
	private long salary;

	public Employee() {
		super();
	}
	
	public Employee(String name, int id, long salary) {
		super();
		this.name = name;
		this.id = id;
		this.salary = salary;
	}
	
	public Employee(Employee emp) {
		super();
		this.name = emp.name;
		this.id = emp.id;
		this.salary = emp.salary;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public long getSalary() {
		return salary;
	}
	public void setSalary(long salary) {
		this.salary = salary;
	}

}
